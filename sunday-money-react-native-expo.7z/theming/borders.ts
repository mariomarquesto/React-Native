export enum BorderRadius {
  half = 4,
  normal = 8,
  times1pt5 = 12,
  times2 = 16,
  times3 = 24,
  rounded = 100,
}
